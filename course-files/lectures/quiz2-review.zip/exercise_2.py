# Name - get_epa_assessment
# Inputs - concentration (int)(required)
# Do - based on the concentration, output one of the assessments
# Outputs - return assessment

def get_epa_assessment(concentration:int):

    assessment = ""

    if concentration <= 50:
        assessment = "good"
        # set assessment to good
    elif concentration <= 100 and concentration > 50:
        assessment = "moderate"
        # set assessment to moderate
    elif concentration > 100:
        assessment = "unhealthy"
        # set assessment to unhealthy

    # if the concentration is 50 or less -> assessment is good
    # otherwise, if the concentration is btw 50 and 100, assessment is moderate
    # otherwise, if the concentration is strictly greater than 100, the asssement
    #    is unhealthy
    
    return assessment

print(get_epa_assessment(25))
