# Note: you MUST use a loop

my_cool_list = ['giraffe', 'zebra', 'yak', 'ox', 'walrus']

for i in [4, 3, 2, 1, 0]:
    print(my_cool_list[i])

for i in [-1, -2, -3, -4, -5]:
    print(my_cool_list[i])
