word: 'Python'
counter: 0
letters: []

while counter less than 6:
    do some stuff

1st Iteration:
    counter: 0
    if word[0] == 'h' -> False
    if word[0] == 't' -> False
    letters.append(word[0])
      appends 'P' to our list of letters
    letters: ['P']
    counter: 1

2nd Iteration:
    counter: 1
    if word[1] == 'h' -> False
    if word[1] == "t" -> False
    append 'y' to our list
    letters: ['P', 'y']
    counter: 2

3rd Iteration
    counter: 2
    if word[2] == 'h' -> False
    if word[2] == 't' -> True
    counter: 3
    CONTINUE (aka stop this iteration of the loop, go to t
              the next one)

4th Iteration:
    counter: 3
    if word[3] == 'h' -> True
    BREAK (aka STOP THE LOOP ENTIRELY)

print(letters)

['P', 'y']
