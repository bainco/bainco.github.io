j: 5
m: 3
k: j / m -> 5 / 3 -> 1.666666667

Is the value of k -> 1?
   1.6667 NOT the same as 1

Otherwise, is the value of k -> 2?
  1.6668 NOT the same as 2
  we don't follow this branch either

Otherwise, is value of k -> 3?
  1.667 NOT the same as 3

-> this will be printed:

default
