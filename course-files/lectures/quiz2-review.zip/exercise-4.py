notes: [48, 50, 52, 53, 55]

for each value in range(0, len(notes))
-> for each value in range(0, 5)
-> for each value in 0, 1, 2, 3, 4

1st Iteration ("Repetition")
  i: 0
  is 0 % 4 == 0? -> True
      print(notes[0] - 12)
      print(48 - 12)
      print(36)
      done

2nd Iteration
  i: 1
  is 1 % 4 == 0? -> False
  otherwise, is 1 % 2 == 0? -> False
  otherwise:
      print(notes[1])
      print(50)
      done

3rd iteration
  i: 2
  is 2 divisible by 4 -> False
  is 2 divisible by 2 -> True
    print(notes[2] + 12)
    print(52 + 12) -> print(64)
    done
4th
  i: 3
  is 3 divi...by 4 -> False
  is 3 divisible by 2 -> False
  print(notes[3])
  print(53)
  done

5th
  i: 4
  is 4 divi. by 4 -> True
    print(notes[4] - 12)
    print(55 - 12)
    print(43)
    done

SUPER DONE



# Output
36
50
64
53
43
